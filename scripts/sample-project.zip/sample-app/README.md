# Sample App

This is a sample project used to test the Lucian Workspace Project Library
import flow.

## Getting Started

```bash
npm install
npm run dev
```

Open http://localhost:3000 in your browser.
