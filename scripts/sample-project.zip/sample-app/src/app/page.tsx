export default function Page() {
  return (
    <main>
      <h1>Hello from Sample App</h1>
    </main>
  );
}
